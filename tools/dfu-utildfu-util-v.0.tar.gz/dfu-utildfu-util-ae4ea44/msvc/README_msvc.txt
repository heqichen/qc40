# (C) Roger Meier <r.meier@siemens.com>
# (C) Pascal Schweizer <pascal.schweizer@siemens.com>
# msvc folder is GPL-2.0+, LGPL-2.1+, BSD-3-Clause or MIT license(SPDX)

Building dfu-util native on Windows with Visual Studio

3rd party dependencies:
- libusbx ( git clone https://github.com/libusbx/libusbx.git )
  - getopt (part of libusbx: libusbx/examples/getopt)

